/*******************************************************************************
  PHYS3071 (and PHYS7073) Assignment 3 Baumgardt 0123456
 
  Program Legendre   (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.
 
  About: This C program evaluates Legendre polynomials by means of 
         Bonnet’s recursion formula 
 
  Compile: gcc -Wall as03-01.c -o as03-01 
 
  Input: The order $n$ and the value $x$ where P_n(x) is to be calculated 
 
  Output:  The value of P_n(x) 
***********************80*character*limit*good*for* a2ps***********************/

#include<stdio.h>
#include<stdlib.h>

// The following function computes the value of P_n(x)

double legendre(double x, int n) {
 double pi,pim1,pim2;
 int i;

 if (n==0)  return(1.0);
 if (n==1)  return(x);

 pim2 = 1.0;
 pim1 = x;

 for (i=2;i<=n;i++) {
    pi   = (2.0*i-1.0)/i*x*pim1-(i-1.0)/i*pim2;
    pim2 = pim1;
    pim1 = pi;
 }
 return(pi);
}


int main() {
 double x;   // x value where Legendre polynomial is to be calculated
 int n;      // n value of the polynomial

 printf("Input the order n of the Legendre polynomial: ");
 scanf("%i",&n);

 if (n<0) {
    printf("Illegal value of n !\n");
    exit(-1);
 }

 printf("Input the x value: ");
 scanf("%lf",&x);

 printf("P_%i(%lf)=%10.5lf\n",n,x,legendre(x,n));

 exit(0);
}
