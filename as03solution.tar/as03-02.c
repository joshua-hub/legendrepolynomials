/*******************************************************************************
  PHYS3071 (and PHYS7073) Assignment 3 Baumgardt 0123456

  Program Associated Legendre   (c) copyleft Holger Baumgardt 2014

  Verbatim copying and distribution of this entire program
  is permitted in any medium, provided this notice is preserved.

  About: This C program evaluates associated Legendre polynomials through 
         two recursion formula

  Compile: gcc -Wall -lm as03-02.c - as03-02

  Input: The order $l$ and $m$ and the value $x$ where P^m_l(x) is to be calculated

  Output:  The value of P^m_l(x)
***********************80*character*limit*good*for* a2ps***********************/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

// The following function computes the value of P^m_l(x)

double assolegendre(double x, int m, int l) {
 double pl[l+1][m+1];
 int i,j;

 if (l==0 && m==0)  return(1.0);
 if (l==1 && m==0)  return(x);

 pl[0][0]=1.0;
 pl[1][0]=x;

 for (i=2;i<=l;i++) 
    pl[i][0]=(double) (2.0*i-1.0)/i*x*pl[i-1][0]-(1.0*i-1.0)/i*pl[i-2][0];

 for (j=1;j<=m;j++) 
   for (i=l-(m-j);i<=l;i++)  
     pl[i][j]=1.0/sqrt(1.0-x*x)*((i-j+1.0)*x*pl[i][j-1]-(i+j-1.0)*pl[i-1][j-1]);

 return(pl[l][m]);
}

int main() {
 double x;
 int l,m;

 printf("Input the l value of the Legendre polynomial: ");
 scanf("%i",&l);

 printf("Input the m value of the Legendre polynomial: ");
 scanf("%i",&m);

 printf("Input the x value: ");
 scanf("%lf",&x);

 if (l<0) {
    printf("Illegal value of l !\n");
    exit(-1);
 }

 if (m<0 || m > l) {
    printf("Illegal value of m !\n");
    exit(-1);
 }

 printf("P^%i_%i(%10.5lf)=%12.5lf\n",m,l,x,assolegendre(x,m,l));

 exit(0);
}
